// Основной JavaScript файл для Flask приложения

document.addEventListener('DOMContentLoaded', function() {
    // 🔧 Инициализация всех компонентов после загрузки DOM
    initFlashMessages();
    initFormValidation();
    initMobileMenu();
    initSmoothScrolling();
});

// 💡 Управление flash-сообщениями
function initFlashMessages() {
    const flashMessages = document.querySelectorAll('.flash');

    flashMessages.forEach(flash => {
        // Автоматическое скрытие через 5 секунд
        setTimeout(() => {
            fadeOut(flash);
        }, 5000);

        // Закрытие по клику
        flash.addEventListener('click', function() {
            fadeOut(this);
        });
    });
}

// 📋 Валидация форм
function initFormValidation() {
    const forms = document.querySelectorAll('form');

    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const requiredFields = this.querySelectorAll('[required]');
            let isValid = true;

            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    showFieldError(field, 'Это поле обязательно для заполнения');
                    isValid = false;
                } else {
                    clearFieldError(field);

                    // Специфическая валидация для email
                    if (field.type === 'email') {
                        if (!isValidEmail(field.value)) {
                            showFieldError(field, 'Введите корректный email адрес');
                            isValid = false;
                        }
                    }

                    // Валидация минимальной длины для имени
                    if (field.name === 'name' && field.value.length < 2) {
                        showFieldError(field, 'Имя должно содержать минимум 2 символа');
                        isValid = false;
                    }
                }
            });

            if (!isValid) {
                e.preventDefault();
                showNotification('Пожалуйста, исправьте ошибки в форме', 'error');
            }
        });
    });
}

// 📱 Мобильное меню
function initMobileMenu() {
    const menuToggle = document.createElement('button');
    menuToggle.innerHTML = '☰';
    menuToggle.className = 'menu-toggle';
    menuToggle.setAttribute('aria-label', 'Открыть меню');

    const navMenu = document.querySelector('.nav-menu');
    const navContainer = document.querySelector('.nav-container');

    if (navMenu && window.innerWidth <= 768) {
        navContainer.appendChild(menuToggle);

        menuToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            menuToggle.classList.toggle('active');
            menuToggle.innerHTML = navMenu.classList.contains('active') ? '✕' : '☰';
        });

        // Закрытие меню при клике на ссылку
        navMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('active');
                menuToggle.classList.remove('active');
                menuToggle.innerHTML = '☰';
            });
        });
    }
}

// 🚀 Плавная прокрутка
function initSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');

    links.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');

            if (href !== '#') {
                const target = document.querySelector(href);

                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
}

// 📧 Валидация email
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// ⚡ Показать ошибку поля
function showFieldError(field, message) {
    clearFieldError(field);

    field.classList.add('error');

    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;

    field.parentNode.appendChild(errorDiv);
}

// 🧹 Очистить ошибку поля
function clearFieldError(field) {
    field.classList.remove('error');

    const existingError = field.parentNode.querySelector('.field-error');
    if (existingError) {
        existingError.remove();
    }
}

// 💫 Плавное исчезновение элемента
function fadeOut(element) {
    element.style.transition = 'opacity 0.3s ease';
    element.style.opacity = '0';

    setTimeout(() => {
        element.style.display = 'none';
    }, 300);
}

// 🔔 Показать уведомление
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button class="notification-close">&times;</button>
    `;

    document.body.appendChild(notification);

    // Анимация появления
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);

    // Закрытие по кнопке
    notification.querySelector('.notification-close').addEventListener('click', () => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    });

    // Автоматическое закрытие
    setTimeout(() => {
        if (notification.parentNode) {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }
    }, 5000);
}

// 🌐 API функции
async function fetchUsers() {
    try {
        const response = await fetch('/api/users');
        const data = await response.json();
        return data.users;
    } catch (error) {
        console.error('Ошибка при загрузке пользователей:', error);
        showNotification('Ошибка при загрузке данных', 'error');
        return [];
    }
}

// 📊 Статистика (пример использования API)
async function loadUserStats() {
    const users = await fetchUsers();

    if (users.length > 0) {
        const statsElement = document.getElementById('user-stats');
        if (statsElement) {
            statsElement.innerHTML = `
                <p>Всего пользователей: <strong>${users.length}</strong></p>
                <p>Последний зарегистрирован: <strong>${users[0].name}</strong></p>
            `;
        }
    }
}

// 📱 Адаптивность
window.addEventListener('resize', function() {
    initMobileMenu();
});

// 🎯 Инициализация при полной загрузке страницы
window.addEventListener('load', function() {
    // Загрузка статистики, если есть соответствующий элемент
    if (document.getElementById('user-stats')) {
        loadUserStats();
    }
});